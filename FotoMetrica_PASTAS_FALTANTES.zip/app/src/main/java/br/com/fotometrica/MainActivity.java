package br.com.fotometrica;

import android.app.Activity;
import android.os.Bundle;
import android.content.ContentValues;
import android.content.Intent;
import android.content.ClipData;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Environment;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.OutputStream;

public final class MainActivity extends Activity {
  private static final int PICK_PHOTO = 4301;
  private WebView web;
  private ValueCallback<Uri[]> chooserCallback;
  private Uri cameraUri;
  private boolean createdCameraUri = false;

  @Override public void onCreate(Bundle savedState) {
    super.onCreate(savedState);
    getWindow().setStatusBarColor(0xff090f1c);
    getWindow().setNavigationBarColor(0xff090f1c);
    web = new WebView(this);
    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowContentAccess(true);
    settings.setAllowFileAccess(true);
    settings.setAllowFileAccessFromFileURLs(false);
    settings.setAllowUniversalAccessFromFileURLs(false);
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return !url.startsWith("file:///android_asset/");
      }
    });
    web.setWebChromeClient(new FileChrome());
    web.addJavascriptInterface(new ImageSaver(), "FotometricaAndroid");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  private final class FileChrome extends WebChromeClient {
    @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
      if (chooserCallback != null) chooserCallback.onReceiveValue(null);
      chooserCallback = callback;
      try {
        if (params.isCaptureEnabled()) {
          ContentValues v = new ContentValues();
          v.put(MediaStore.Images.Media.DISPLAY_NAME, "FotoMetrica_Original_" + System.currentTimeMillis() + ".jpg");
          v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
          v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FotoMetrica");
          cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
          createdCameraUri = cameraUri != null;
          if (cameraUri == null) throw new IllegalStateException("Não foi possível criar arquivo para foto");
          Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
          intent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
          intent.setClipData(ClipData.newUri(getContentResolver(), "FotoMétrica", cameraUri));
          intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
          startActivityForResult(intent, PICK_PHOTO);
        } else {
          cameraUri = null;
          createdCameraUri = false;
          Intent choose = new Intent(Intent.ACTION_GET_CONTENT);
          choose.setType("image/*");
          choose.addCategory(Intent.CATEGORY_OPENABLE);
          startActivityForResult(Intent.createChooser(choose, "Selecione a imagem"), PICK_PHOTO);
        }
      } catch (Exception ex) {
        chooserCallback.onReceiveValue(null);
        chooserCallback = null;
        if (cameraUri != null) try { getContentResolver().delete(cameraUri, null, null); } catch (Exception ignored) {}
        cameraUri = null;
        createdCameraUri = false;
        return false;
      }
      return true;
    }
  }

  @Override protected void onActivityResult(int request, int result, Intent data) {
    super.onActivityResult(request, result, data);
    if (request != PICK_PHOTO || chooserCallback == null) return;
    Uri resultUri = null;
    if (result == RESULT_OK) resultUri = (data != null && data.getData() != null) ? data.getData() : cameraUri;
    if (result != RESULT_OK && cameraUri != null) try { getContentResolver().delete(cameraUri, null, null); } catch (Exception ignored) {}
    chooserCallback.onReceiveValue(resultUri != null ? new Uri[]{resultUri} : null);
    chooserCallback = null;
    cameraUri = null;
    createdCameraUri = false;
  }

  private Uri writeToGallery(String base64, String fileName) throws Exception {
    byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
    ContentValues values = new ContentValues();
    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName.replaceAll("[^a-zA-Z0-9_.-]", "_"));
    values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
    values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FotoMetrica");
    values.put(MediaStore.Images.Media.IS_PENDING, 1);
    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
    if (uri == null) throw new IllegalStateException("Falha ao criar imagem");
    try {
      try (OutputStream out = getContentResolver().openOutputStream(uri)) {
        if (out == null) throw new IllegalStateException("Falha ao abrir imagem");
        out.write(bytes);
      }
      ContentValues ready = new ContentValues();ready.put(MediaStore.Images.Media.IS_PENDING, 0);
      getContentResolver().update(uri, ready, null, null);
      return uri;
    } catch (Exception ex) {
      getContentResolver().delete(uri, null, null);
      throw ex;
    }
  }

  public final class ImageSaver {
    @JavascriptInterface public void saveImage(String base64, String fileName) {
      boolean success;
      try { writeToGallery(base64, fileName); success = true; }
      catch (Exception ex) { success = false; }
      final boolean saved = success;
      runOnUiThread(() -> web.evaluateJavascript("window.fotometricaSaved(" + saved + ")", null));
    }

    @JavascriptInterface public void shareImage(String base64, String fileName) {
      try {
        Uri uri = writeToGallery(base64, "Compartilhar_" + System.currentTimeMillis() + ".jpg");
        runOnUiThread(() -> {
          try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/jpeg");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setClipData(ClipData.newUri(getContentResolver(), "FotoMétrica", uri));
            startActivity(Intent.createChooser(send, "Compartilhar medição"));
            web.evaluateJavascript("window.fotometricaShared(true)", null);
          } catch (Exception ex) {web.evaluateJavascript("window.fotometricaShared(false)", null);}
        });
      } catch (Exception ex) {runOnUiThread(() -> web.evaluateJavascript("window.fotometricaShared(false)", null));}
    }
  }
}
